package com.bit.board.service;

public interface BbsService {

}
