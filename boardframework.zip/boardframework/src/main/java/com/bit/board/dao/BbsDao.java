package com.bit.board.dao;

public interface BbsDao {

}
